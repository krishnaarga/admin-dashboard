<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title> Synergy :: Home </title>

    <link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="css/sidebar.css">
</head>
<body>
 
  <?php require_once('assets/header.php'); ?>

  <?php require_once('assets/sidebar.php'); ?>
  <!-- sidebar-wrapper  -->
  <main class="page-content">
    <section class="container-fluid">
      <h3 class="text-muted">Home</h3>
    </section>
    <hr>

  </main>
    
  <!-- page-content" -->
</div><!-- Start div in assets/slider.php -->
<!-- page-wrapper -->




    <?php include_once('assets/footer.php'); ?>


    <script src="js/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/sidebar.js"></script>

</body>
</html>