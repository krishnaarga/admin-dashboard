<footer class="bg-secondary text-center text-white py-3 font-weight-bold">
      Copyright &copy; 2018 -  <?php echo date('Y'); ?> Study2Europe | Powered by Synergy International LLC
</footer>