<header class="navbar navbar-expand-lg navbar-light bg-light fixed-top" style="border-bottom: 0.5px solid black; box-shadow: 0 0 10px gray; z-index: 2000">
    <a class="navbar-brand font-weight-bold" href="#">SYNERGY</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbartoggle">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbartoggle">
      <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
        <li class="nav-item active">
          <a class="nav-link" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Activaties</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Student Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Course Details</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Payment</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Document</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Sales Persone</a>
        </li>
      </ul>
      <!-- <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form> -->
    </div>
  </header>